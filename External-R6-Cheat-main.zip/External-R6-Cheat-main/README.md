# External R6 Cheat (Outdated)

Basic R6 Cheat

## Features
> Aimbot (Toggle with F1)

> ESP (Toggle with F2)

## Information
This should serve as a base to help with R6 reversal.

Make sure not to use this on an account you care about.
